<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <title>{{$title}}</title>
    
    <!-- 引入主题样式 -->
    <link rel="stylesheet" href="/theme/{{$theme}}/assets/style.css?v={{$version}}">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🚀</text></svg>">
    
    <!-- 预加载关键资源 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Meta标签 -->
    <meta name="description" content="{{$description}}">
    <meta name="theme-color" content="#18CF96">
</head>
<body>
    <!-- 主要应用容器 -->
    <div id="app">
        <!-- 加载动画 -->
        <div class="airrocket-loading">
            <div class="loading-content">
                <div class="rocket-icon">🚀</div>
                <div class="loading-text">AirRocket 启动中...</div>
                <div class="loading-bar">
                    <div class="loading-progress"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- 全局配置脚本 -->
    <script>
        window.routerBase = "/";
    </script>
    
    <?php
        $settingsData = [
            'title' => $title,
            'assets_path' => '/theme/'.$theme.'/assets',
            'theme' => [
                'name' => 'AirRocket',
                'color' => $theme_config['theme_color'] ?? 'teal',
                'sidebar_style' => $theme_config['sidebar_style'] ?? 'dark',
                'enable_animations' => ($theme_config['enable_animations'] ?? 'true') === 'true',
                'card_opacity' => $theme_config['card_opacity'] ?? 'normal',
                'show_charts' => ($theme_config['show_charts'] ?? 'true') === 'true'
            ],
            'version' => $version,
            'background_url' => $theme_config['background_url'] ?? '',
            'description' => $description,
            'logo' => $logo,
            'i18n' => [
                'zh-CN',
                'en-US', 
                'ja-JP',
                'vi-VN',
                'ko-KR',
                'zh-TW',
                'fa-IR'
            ]
        ];
    ?>
    <script>
        window.settings = <?= json_encode($settingsData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
        
        // 主题颜色配置
        window.themeColors = {
            teal: "#18CF96",
            blue: "#3B82F6",
            purple: "#8B5CF6",
            green: "#10B981",
            orange: "#F59E0B"
        };
    </script>

    <!-- 引入主要应用脚本 -->
    <script type="module" crossorigin src="/theme/{{$theme}}/assets/umi.js"></script>
    
    <!-- 主题自定义脚本 -->
    <script src="/theme/{{$theme}}/assets/theme.js?v={{$version}}"></script>
    
    <!-- 自定义HTML内容 -->
    {!! $theme_config['custom_html'] ?? '' !!}
</body>
</html> 